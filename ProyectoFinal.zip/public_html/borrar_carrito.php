<?php
session_start();
$_SESSION['idCursos'] = [];


header('Location:index.php');
